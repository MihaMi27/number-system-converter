package com.vaje.pretvorniknsp

import android.widget.Toast
import java.lang.Integer.parseInt

class Pretvorbe {

    fun binToDec(s: String): String {
        var rez = 0
        var x: Double
        var pos = true
        for (c in s) {
            if (c != '1' && c != '0') {
                pos = false
            }
        }
        for (i in s.indices) {
            if (s[i] == '1') {
                 x = Math.pow(2.0,(s.length-1-i).toDouble())
                rez+=x.toInt()
            }
        }
        return rez.toString()
    }

    fun hexToDec(s: String): String {
        var rez = 0
        var x: Double
        var v = 0
        for (i in s.indices) {
            if (s[i].isLetterOrDigit()) {
                if (!s[i].isDigit() && ('A'..'F').contains(s[i])) {
                    v = s[i].toInt()-55
                } else if (s[i].isDigit()) {
                    v = parseInt(s[i].toString())
                } else {
                    println("not in char range or not a digit")
                }

            }
            if (s[i] != '0') {
                x = Math.pow(16.0,(s.length-1-i).toDouble())*v
                rez+=x.toInt()
            }
        }
        return rez.toString()
    }

    fun bcdToDec(s: String) : String {
        var rez = ""
        var znaki = s.split(" ")
        for (znak in znaki) {
            rez+=binToDec(znak)
        }

        return rez
    }

    fun decToBin(x: Int) : String {
        var rez = ""
        var xx = x
        var ost: Int
        while (xx != 0) {
            ost = xx % 2
            xx = (xx / 2)
            rez+=ost.toString()
        }
        rez = rez.reversed()

        return rez
    }

    fun decToHex(x: Int) : String {
        var rez = ""
        var xx = x
        var ost: Int
        while (xx != 0) {
            ost = xx % 16
            xx = (xx / 16)
            if (ost > 9) {
                ost+=55
                rez+=ost.toChar()
            } else {
                rez+=ost.toString()
            }
        }
        rez = rez.reversed()

        return rez
    }

    fun decToBcd(x: Int) : String {
        var rez = ""
        var c : Int
        for (char in x.toString()) {
            c = char.toInt() - 48
            rez+=(decToBin(c).padStart(4,'0'))+" "
        }

        return rez
    }


}
