package com.vaje.pretvorniknsp

import android.content.res.Configuration
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.*

class MainActivity : AppCompatActivity() {

    var textColor = Color.BLACK
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val original: EditText = findViewById(R.id.original)
        val pretvorba: TextView = findViewById(R.id.pretvorba)
        var vmesni = ""

        when (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) {
            Configuration.UI_MODE_NIGHT_YES -> {
                original.setTextColor(Color.WHITE)
                pretvorba.setTextColor(Color.WHITE)
                original.setBackgroundColor(Color.argb(80,232,232,232))
                pretvorba.setBackgroundColor(Color.argb(80,232,232,232))
            }
            Configuration.UI_MODE_NIGHT_NO -> {
                original.setTextColor(Color.BLACK)
                pretvorba.setTextColor(Color.BLACK)
                original.setBackgroundColor(Color.argb(80,37,37,37))
                pretvorba.setBackgroundColor(Color.argb(80,37,37,37))
            }
            else -> {}
        }
        var originalText = ""
        original.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                originalText = original.text.toString()
                println("OriginalText: ${originalText}")
                false
            } else {
                false
            }
        }

        val pretvori: Button = findViewById(R.id.pretvori)
        var pretvorbaText = ""
        val from: RadioGroup = findViewById(R.id.radioGroup2)
        val to: RadioGroup = findViewById(R.id.radioGroup)
        var fromId = -1
        var toId = -1
        from.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            fromId = group.checkedRadioButtonId
        })
        to.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            toId = group.checkedRadioButtonId
        })

        pretvori.setOnClickListener {
            val pretvorbe = Pretvorbe()
            when (fromId) {
                R.id.dec1 -> {

                }
                R.id.bin1 -> {
                    vmesni = pretvorbe.binToDec(originalText)
                }
                R.id.hex1 -> {
                    vmesni = pretvorbe.hexToDec(originalText)
                }
                R.id.bcd1 -> {
                    vmesni = pretvorbe.bcdToDec(originalText)
                }
                -1 -> {
                    Toast.makeText(applicationContext,"Nisi izbral levega stolpca",Toast.LENGTH_SHORT)
                }
            }
            when (toId) {
                R.id.dec2 -> {
                    pretvorbaText = vmesni
                }
                R.id.bin2 -> {
                    var x = originalText.toInt()
                    pretvorbaText = pretvorbe.decToBin(x)
                }
                R.id.hex2 -> {
                    var x = originalText.toInt()
                    pretvorbaText = pretvorbe.decToHex(x)
                }
                R.id.bcd2 -> {
                    var x = originalText.toInt()
                    pretvorbaText = pretvorbe.decToBcd(x)
                }
                -1 -> {
                    Toast.makeText(applicationContext,"Nisi izbral desnega stolpca",Toast.LENGTH_SHORT)
                }
            }

            pretvorba.text = pretvorbaText
        }

    }
}